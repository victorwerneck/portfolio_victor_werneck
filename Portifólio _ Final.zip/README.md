
  # Portifólio | Final

  This is a code bundle for Portifólio | Final. The original project is available at https://www.figma.com/design/TSraO3yL5CijQa15gFP33x/Portif%C3%B3lio-%7C-Final.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  